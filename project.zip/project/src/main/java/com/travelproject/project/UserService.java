package com.travelproject.project;

import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class UserService {

    private UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public Users saveUser(Users users) {
        return (Users) userRepository.save(users);

    }

    public List<Users> getAllUsers() {
        return userRepository.findAll();
    }

}
