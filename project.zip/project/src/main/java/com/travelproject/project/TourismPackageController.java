package com.travelproject.project;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class TourismPackageController {

    @Autowired
    private TourismPackageRepository repository;

    @GetMapping("/submit")
    public String showForm(Model model) {
        model.addAttribute("tourismPackage", new TourismPackage());
        return "form";
    }

    @PostMapping("/submit")
    public String submitForm(@ModelAttribute TourismPackage tourismPackage, Model model) {
        repository.save(tourismPackage);
        model.addAttribute("message", "Tourism Package Inquiry Submitted Successfully!");
        return "form";
    }

}