package com.travelproject.project;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class HotelBookingController {
    @Autowired
    private HotelBookingService hotelbookingService;

    @GetMapping("/booking")
    public String showBookingForm(Model model) {
        model.addAttribute("booking", new HotelBooking());
        return "bookingForm";
    }

    @PostMapping("/booking")
    public String submitBooking(@ModelAttribute HotelBooking hotelbooking, Model model) {
        hotelbookingService.saveBooking(hotelbooking);
        model.addAttribute("booking", hotelbooking);
        return "success";
    }
}