package com.travelproject.project;

import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.ui.Model;

@Controller
public class LoginController {

    private LoginServices loginServices;

    public LoginController(LoginServices loginServices) {
        this.loginServices = loginServices;
    }

    @GetMapping("/login")
    public String getAdminForm() {

        return "login";
    }

    @PostMapping("/login")
    public String getLoginStatus(@ModelAttribute Login login, Model model) {
        loginServices.saveUser(login);
        model.addAttribute("message", "login Submitted Successfully!");
        return "login";

    }

}