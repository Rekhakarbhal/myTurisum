package com.travelproject.project;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class TourismPackage {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private String fullName;
	private String email;
	private String phoneNumber;
	private String destination;
	private String travelStartDate;
	private String travelEndDate;
	private int numberOfAdults;
	private int numberOfChildren;
	private String packageType;
	private String accommodation;
	private String activities;
	private String specialRequests;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getTravelStartDate() {
		return travelStartDate;
	}

	public void setTravelStartDate(String travelStartDate) {
		this.travelStartDate = travelStartDate;
	}

	public String getTravelEndDate() {
		return travelEndDate;
	}

	public void setTravelEndDate(String travelEndDate) {
		this.travelEndDate = travelEndDate;
	}

	public int getNumberOfAdults() {
		return numberOfAdults;
	}

	public void setNumberOfAdults(int numberOfAdults) {
		this.numberOfAdults = numberOfAdults;
	}

	public int getNumberOfChildren() {
		return numberOfChildren;
	}

	public void setNumberOfChildren(int numberOfChildren) {
		this.numberOfChildren = numberOfChildren;
	}

	public String getPackageType() {
		return packageType;
	}

	public void setPackageType(String packageType) {
		this.packageType = packageType;
	}

	public String getAccommodation() {
		return accommodation;
	}

	public void setAccommodation(String accommodation) {
		this.accommodation = accommodation;
	}

	public String getActivities() {
		return activities;
	}

	public void setActivities(String activities) {
		this.activities = activities;
	}

	public String getSpecialRequests() {
		return specialRequests;
	}

	public void setSpecialRequests(String specialRequests) {
		this.specialRequests = specialRequests;
	}

	public TourismPackage(Long id, String fullName, String email, String phoneNumber, String destination,
			String travelStartDate, String travelEndDate, int numberOfAdults, int numberOfChildren, String packageType,
			String accommodation, String activities, String specialRequests) {
		super();
		this.id = id;
		this.fullName = fullName;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.destination = destination;
		this.travelStartDate = travelStartDate;
		this.travelEndDate = travelEndDate;
		this.numberOfAdults = numberOfAdults;
		this.numberOfChildren = numberOfChildren;
		this.packageType = packageType;
		this.accommodation = accommodation;
		this.activities = activities;
		this.specialRequests = specialRequests;
	}

	@Override
	public String toString() {
		return "TourismPackage [id=" + id + ", fullName=" + fullName + ", email=" + email + ", phoneNumber="
				+ phoneNumber + ", destination=" + destination + ", travelStartDate=" + travelStartDate
				+ ", travelEndDate=" + travelEndDate + ", numberOfAdults=" + numberOfAdults + ", numberOfChildren="
				+ numberOfChildren + ", packageType=" + packageType + ", accommodation=" + accommodation
				+ ", activities=" + activities + ", specialRequests=" + specialRequests + "]";
	}

	public TourismPackage() {
		super();
		// TODO Auto-generated constructor stub
	}

}
