package com.travelproject.project;

import org.springframework.data.jpa.repository.JpaRepository;

public interface TourismPackageRepository extends JpaRepository<TourismPackage, Long> {
}