package com.travelproject.project;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ProjectController {

    @GetMapping("/one")
    public String getHome() {

        return "first";
    }

    @GetMapping("/about")
    public String getAbout() {

        return "about";
    }

    @GetMapping("/service")
    public String Services() {

        return "service";
    }

    @GetMapping("/destinations")
    public String destinations() {
        return "destinations"; // Corresponds to destinations.html in templates
    }

    @PostMapping("/destinations")
    public String Moredestinations() {
        return "destinations"; // Corresponds to destinations.html in templates
    }

    @GetMapping("/contact")
    public String contact() {
        return "contact"; // Corresponds to contact.html in templates
    }
}
