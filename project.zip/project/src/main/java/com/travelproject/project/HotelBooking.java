package com.travelproject.project;

import jakarta.persistence.*;

import java.sql.Date;

@Entity
public class HotelBooking {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String fullName;
    private String email;
    private String contactNumber;
    private String numberOfGuests;
    private String destination;
    private Date travelStartDate;
    private Date travelEndDate;
    private int numberOfAdults;
    private int numberOfChildren;
    private String packageType;
    private String accommodation;
    private String activities;
    private String specialRequests;
    private String roomType;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getNumberOfGuests() {
        return numberOfGuests;
    }

    public void setNumberOfGuests(String numberOfGuests) {
        this.numberOfGuests = numberOfGuests;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public Date getTravelStartDate() {
        return travelStartDate;
    }

    public void setTravelStartDate(Date travelStartDate) {
        this.travelStartDate = travelStartDate;
    }

    public Date getTravelEndDate() {
        return travelEndDate;
    }

    public void setTravelEndDate(Date travelEndDate) {
        this.travelEndDate = travelEndDate;
    }

    public int getNumberOfAdults() {
        return numberOfAdults;
    }

    public void setNumberOfAdults(int numberOfAdults) {
        this.numberOfAdults = numberOfAdults;
    }

    public int getNumberOfChildren() {
        return numberOfChildren;
    }

    public void setNumberOfChildren(int numberOfChildren) {
        this.numberOfChildren = numberOfChildren;
    }

    public String getPackageType() {
        return packageType;
    }

    public void setPackageType(String packageType) {
        this.packageType = packageType;
    }

    public String getAccommodation() {
        return accommodation;
    }

    public void setAccommodation(String accommodation) {
        this.accommodation = accommodation;
    }

    public String getActivities() {
        return activities;
    }

    public void setActivities(String activities) {
        this.activities = activities;
    }

    public String getSpecialRequests() {
        return specialRequests;
    }

    public void setSpecialRequests(String specialRequests) {
        this.specialRequests = specialRequests;
    }

    public String getRoomType() {
        return roomType;
    }

    public void setRoomType(String roomType) {
        this.roomType = roomType;
    }

    public HotelBooking(Long id, String fullName, String email, String contactNumber, String numberOfGuests,
            String destination, Date travelStartDate, Date travelEndDate, int numberOfAdults, int numberOfChildren,
            String packageType, String accommodation, String activities, String specialRequests, String roomType) {
        super();
        this.id = id;
        this.fullName = fullName;
        this.email = email;
        this.contactNumber = contactNumber;
        this.numberOfGuests = numberOfGuests;
        this.destination = destination;
        this.travelStartDate = travelStartDate;
        this.travelEndDate = travelEndDate;
        this.numberOfAdults = numberOfAdults;
        this.numberOfChildren = numberOfChildren;
        this.packageType = packageType;
        this.accommodation = accommodation;
        this.activities = activities;
        this.specialRequests = specialRequests;
        this.roomType = roomType;
    }

    @Override
    public String toString() {
        return "HotelBooking [id=" + id + ", fullName=" + fullName + ", email=" + email + ", contactNumber="
                + contactNumber + ", numberOfGuests=" + numberOfGuests + ", destination=" + destination
                + ", travelStartDate=" + travelStartDate + ", travelEndDate=" + travelEndDate + ", numberOfAdults="
                + numberOfAdults + ", numberOfChildren=" + numberOfChildren + ", packageType=" + packageType
                + ", accommodation=" + accommodation + ", activities=" + activities + ", specialRequests="
                + specialRequests + ", roomType=" + roomType + "]";
    }

    public HotelBooking() {
        super();
        // TODO Auto-generated constructor stub
    }

}