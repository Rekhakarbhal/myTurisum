package com.travelproject.project;

import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class LoginServices {

	private LoginRepository loginRepository;

	public LoginServices(LoginRepository loginRepository) {
		this.loginRepository = loginRepository;
	}

	public Login saveUser(Login login) {
		return (Login) loginRepository.save(login);

	}

	public List<Login> getAllUsers() {
		return loginRepository.findAll();
	}

	public boolean verifyLogin(String username, String password) {

		List<Login> all = loginRepository.findAll();

		return true;

	}

}
