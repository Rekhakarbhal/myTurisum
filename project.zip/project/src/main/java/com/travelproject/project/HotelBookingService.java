package com.travelproject.project;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class HotelBookingService {
    @Autowired
    private HotelBookingRepository hotelbookingRepository;

    public HotelBooking saveBooking(HotelBooking hotelbooking) {
        return hotelbookingRepository.save(hotelbooking);
    }
}