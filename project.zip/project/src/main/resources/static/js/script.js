// Modal functionality
const readMoreButtons = document.querySelectorAll('.read-more');
const modal = document.getElementById('modal');
const modalTitle = document.getElementById('modal-title');
const modalDescription = document.getElementById('modal-description');
const modalPrice = document.getElementById('modal-price');
const closeModal = document.querySelector('.close');

// Travel package details
const packageDetails = {
    beach: {
        title: "Beach Paradise",
        description: "Spend your vacation at the stunning beaches of the Caribbean. Enjoy water sports, relaxing sunsets, and luxurious resorts.",
        price: "Price: $1,200 per person"
    },
    mountain: {
        title: "Mountain Adventure",
        description: "Take a thrilling adventure in the mountains. Go hiking, explore scenic landscapes, and enjoy cozy cabins.",
        price: "Price: $900 per person"
    },
    city: {
        title: "City Explorer",
        description: "Immerse yourself in the vibrant life of metropolitan cities. Explore landmarks, dine in fine restaurants, and experience nightlife.",
        price: "Price: $1,500 per person"
    }
};

// Open modal with details
readMoreButtons.forEach(button => {
    button.addEventListener('click', () => {
        const packageType = button.dataset.package;
        const details = packageDetails[packageType];

        modalTitle.textContent = details.title;
        modalDescription.textContent = details.description;
        modalPrice.textContent = details.price;

        modal.style.display = 'flex';
    });
});

// Close modal
closeModal.addEventListener('click', () => {
    modal.style.display = 'none';
});

// Close modal when clicking outside the modal content
window.addEventListener('click', (e) => {
    if (e.target === modal) {
        modal.style.display = 'none';
    }
});
function showMoreInfo() {
    const moreInfoDiv = document.getElementById('more-info');
    moreInfoDiv.style.display = moreInfoDiv.style.display === 'block' ? 'none' : 'block';
}